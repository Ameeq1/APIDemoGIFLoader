import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

declare var $: any;

@Component({
  selector: 'app-photos',
  templateUrl: './photos.component.html',
  styleUrls: ['./photos.component.css']
})
export class PhotosComponent implements OnInit {
 private URL="https://jsonplaceholder.typicode.com/photos";
 photos: any;
  constructor(private http:HttpClient) { }

  ngOnInit(): void {
    this.http.get(this.URL)
    .subscribe(res=>{
      if(res){
        this.hideloader();
      }
      this.photos=res;
    })
  }

  // Function is defined
  hideloader() {
  $("#loading").css("display","none");
    // Setting display of spinner
    // element to none
    // document.getElementById('loading')
    //     .style.display = 'none';
}

}
